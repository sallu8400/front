import Layout from "./Layout"

const Products = ()=>{
    return (
        <Layout>
            <div>
                sdfsad
            </div>
        </Layout>
    )
}

export default Products